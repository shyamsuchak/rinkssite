<?php  
/*#--------------------------------------------------------------------------#*/
/*# Site Builder - A Complete Content Management Solution - Administrator    #*/
/*# ------------------------------------------------------------------------ #*/
/*# Kre8iveminds                                                         	 #*/
/*# 16, Gangadhar Babu Lane, Near Central Metro                              #*/
/*# Kolkata - 700012                                                         #*/
/*# Websites:  http://www.kre8iveminds.com                                   #*/
/*#--------------------------------------------------------------------------#*/
                                    
/*#----------------Your site name--------------------------------------------#*/
define('CONFIG_SITENAME', 'Broadway');
                  
/*#----------------MySQL hostname--------------------------------------------#*/
define('DB_SERVER_HOST', 'localhost');
//define('DB_SERVER_HOST', 'p50mysql221.secureserver.net');


/*#----------------MySQL database username-----------------------------------#*/
//define('DB_SERVER_USERNAME', 'azaanali_bdway');
//define('DB_SERVER_USERNAME', 'wisdomhosp');

define('DB_SERVER_USERNAME', 'acmephar_u');
/*#----------------MySQL database password-----------------------------------#*/
//define('DB_SERVER_PASSWORD', 'poiuy09876');
//define('DB_SERVER_PASSWORD', 'Poiuy09876');
define('DB_SERVER_PASSWORD', '0G&-k-z^t$Pk');
         
/*#----------------The name of the database for Site Builder-----------------#*/
//define('DB_SERVER_DATABASE', 'azaanali_broadway');
//define('DB_SERVER_DATABASE', 'wisdomhosp');
define('DB_SERVER_DATABASE', 'acmephar_DB');
/*#----------------Database Prefix-------------------------------------------#*/
define('DB_SERVER_PREFIX', 'k8_');
                                                                         
/*#----------------Database Prefix-------------------------------------------#*/
define('LOG_SESSION_PREFIX', 'k8_');

/*#----------------Root Path-------------------------------------------------#*/
//define('CFG_SITE_ROOT_PATH', 'http://sur-saaz.com/');
                      
define('SHOW_TITLE', 1);
define('ARTICLES_LIMIT', 100);
define('SHOW_MORE_BUTTON', 1);
?>