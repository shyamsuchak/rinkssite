<?php        
/*#--------------------------------------------------------------------------#*/
/*# Site Builder - A Complete Content Management Solution - Administrator    #*/
/*# ------------------------------------------------------------------------ #*/
/*# Kre8iveminds                                                         	 #*/
/*# 16, Gangadhar Babu Lane, Near Central Metro                              #*/
/*# Kolkata - 700012                                                         #*/
/*# Websites:  http://www.kre8iveminds.com                                   #*/
/*#--------------------------------------------------------------------------#*/ 
define('CONSTANT_TEXT_USERNAME','Username:');
define('CONSTANT_TEXT_PASSWORD','Password:');
define('CONSTANT_TEXT_REMEMBER_ME','Remember me');
define('CONSTANT_TEXT_FORGET_PASSWORD','Forget your username or password?');
define('CONSTANT_BUTTON_SIGN_IN','Sign In');
define('CONSTANT_BUTTON_RESET','Reset');    
define('CONSTANT_ERROR_INVALID_USERNAME','Invalid username or password.');
?>