<?php        
/*#--------------------------------------------------------------------------#*/
/*# Site Builder - A Complete Content Management Solution - Administrator    #*/
/*# ------------------------------------------------------------------------ #*/
/*# Kre8iveminds                                                         	 #*/
/*# 16, Gangadhar Babu Lane, Near Central Metro                              #*/
/*# Kolkata - 700012                                                         #*/
/*# Websites:  http://www.kre8iveminds.com                                   #*/
/*#--------------------------------------------------------------------------#*/  
/*# lang_common.php                                                          #*/
/*# ------------------------------------------------------------------------ #*/
                                                                                                
define('CONSTANT_META_TITLE','Site Builder - A Complete Content Management Solution - Administrator Control Panel');
define('CONSTANT_SITE_NAME','Site Builder');
define('CONSTANT_TEXT_WELCOME','Welcome to ');
define('CONSTANT_TEXT_GUEST','Guest');
?>