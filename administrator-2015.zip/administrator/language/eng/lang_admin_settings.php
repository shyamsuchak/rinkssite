<?php       
/*#--------------------------------------------------------------------------#*/
/*# Site Builder - A Complete Content Management Solution - Administrator    #*/
/*# ------------------------------------------------------------------------ #*/
/*# Kre8iveminds                                                         	 #*/
/*# 16, Gangadhar Babu Lane, Near Central Metro                              #*/
/*# Kolkata - 700012                                                         #*/
/*# Websites:  http://www.kre8iveminds.com                                   #*/
/*#--------------------------------------------------------------------------#*/  
/*# lang_index.php                                                           #*/
/*# ------------------------------------------------------------------------ #*/

define('CONSTANT_CHECKBOX_ALL_TITLE_CAPTION','Check All/Uncheck All');  
define('CONSTANT_CHECKBOX_TITLE_CAPTION','Check/Uncheck');
define('CONSTANT_VIEW_HEADING_SERIAL_NUMBER','Sl. No.'); 
define('CONSTANT_VIEW_HEADING_CAPTION','Caption');
define('CONSTANT_VIEW_HEADING_VALUE','Value');
define('CONSTANT_MAIN_HEADING','Admin Settings');
define('CONSTANT_EDIT_HEADING','Edit Admin Setting');
define('CONSTANT_BUTTON_TEXT_SAVE','Save');
define('CONSTANT_BUTTON_TEXT_EDIT','Edit');
define('CONSTANT_BUTTON_TEXT_CANCEL','Cancel');
define('CONSTANT_BUTTON_TEXT_HELP','Help');
?>